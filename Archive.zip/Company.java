package company_EMS;
import java.util.List;
import java.util.ArrayList;
import java.util.TreeMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

public class Company {
    public String name;
    public static List<Department> departments = new ArrayList<Department>();
    //departments = new ArrayList<departments>();

    public Company(String name){
        this.name = name;
        
    }
    public void addDepartment(Department d){
        departments.add(d);
    }

    public void hire(String name){
        Random rand = new Random();
        int salary = rand.nextInt(200000);
      
        int departmentIndex = rand.nextInt(departments.size()-1);
        Employee newEmployee = new Employee(name, salary);
        Department assignedDepartment = departments.get(departmentIndex);
        assignedDepartment.add(newEmployee);
    }

    public void fire(Integer id){
        for(Department department: departments){     
            TreeMap<Integer, Employee> employList = department.getEmployeeListById();
            if(employList.containsKey(id)){
                employList.remove(id);
                return;
            }
        }
        System.out.println("Employee not found");
        return;
    }

    public void changeFund(String departmentName, int amount){
        for(Department department: departments){
            if(department.getName().equals(departmentName)){
                department.updateBudget(amount);
            }
        }
    }
    


    public void printDepartmentList(){
        for(Department department:departments){
            System.out.println(department.getName()+ ": [ phone: " + department.getPhoneNumber() + " budget: " + department.getBudge() + " ]");
            System.out.println("Member size: "+ department.memberSize());
            if(department.memberSize()>0){
                //var employeeList = department.getEmployeeListById();
                System.out.print("Member: ");
                for(Map.Entry<Integer,Employee>entry:department.employeeListById.entrySet()){

                    System.out.print(entry.getValue().getName()+", ID: " +entry.getKey()+" ");
                }

            }
            System.out.println("");
        }
    }
}
