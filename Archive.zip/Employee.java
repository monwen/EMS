package company_EMS;

public class Employee{
    private static Integer count= 1;
    private String name;
    private Integer id;
    private int salary;

    public Employee(String name, int salary){
        
        this.name = name;
        this.id = count;
        this.salary = salary;
        count +=1;
    }
    public String getName(){
        return this.name;
    }

    public Integer getId(){
        return this.id;
    }

    public void setName(String name){
        this.name= name;
    }
    public void setSalary(int salary){
        this.salary =  salary;
    }

    
}